const VIEWS={flow:'گردش‌کار',catalog:'کتابخانه ماژول‌ها',bitmap:'طرح نقشه‌بیتی',vector:'طراحی برداری',weave:'ساخت بافت',bank:'بانک بافت پروژه',sim:'شبیه‌سازی پارچه',icons:'آیکون‌ها و گزینه‌ها',record:'شناسنامه طرح',pipeline:'گردش‌کار کامل'};
const VIEWMOD={flow:'weave-mapping',bitmap:'bitmap-import',vector:'vector-editor',weave:'weave-build',bank:'weave-library',sim:'fabric-simulation',record:'design-record'};
const VIEWFOR={'bitmap-import':'bitmap','vector-editor':'vector','vector-import':'vector','pattern-edit':'vector','blank-canvas':'vector','weave-build':'weave','weave-mapping':'weave','weave-library':'bank','fabric-simulation':'sim','design-record':'record'};
const defs={
'bitmap-import':['انتخاب فایل و صفحه','عرض|width|1204 px','ارتفاع|height|1203 px','صفحه|file|1'],
'vector-import':['ورود مسیرهای برداری','نوع فایل|svg|SVG','مقیاس|resize|100%','رنگ|palette|اصلی'],
'blank-canvas':['آغاز یک طرح تازه','عرض|width|640 px','ارتفاع|height|480 px','زمینه|palette|سفید'],
'machine-import':['ورود داده‌های ماشین','قالب|file|تعیین در پروژه','ماشین|machine-definition|ماشین پروژه'],
'monochrome':['کاهش تصویر به دو رنگ','آستانه|sliders|128','معکوس|invert|خاموش'],
'resize':['تغییر ابعاد نقشه','عرض|width|640 px','ارتفاع|height|480 px','تناسب|lock|حفظ شود'],
'crop':['انتخاب محدوده طرح','عرض|width|320 px','ارتفاع|height|320 px','مبدأ|select|0, 0'],
'pattern-edit':['ویرایش شکل و هندسه','ابزار|pencil|مداد','اندازه|width|2 px'],
'vector-editor':['ویرایش مسیرها و لایه‌ها','عرض|width|640 px','ارتفاع|height|480 px','شفافیت|opacity|100%'],
'repeat':['تنظیم تکرار نقش','روش|repeat|مستقیم','تکرار افقی|width|2','تکرار عمودی|height|2'],
'color-management':['ویرایش پالت پروژه','پالت|palette|گلستان','روش تطبیق|palette-match|نزدیک‌ترین رنگ'],
'palette-match':['نگاشت رنگ‌های طرح','پالت|palette|گلستان','مرجع|open|پالت پروژه'],
'compare-designs':['مقایسه دو نسخه نقش','طرح اول|file|گلستان','روش|compare-designs|کنار هم'],
'rect-mask':['محدوده مستطیلی ماسک','عرض|width|160 px','ارتفاع|height|160 px'],
'apply-mask':['ترکیب ماسک و طرح','حالت|apply-mask|داخل محدوده','معکوس|invert|خاموش'],
'ai':['پیشنهاد برای طرح','ورودی|input|نقش انتخاب‌شده','تعداد پیشنهاد|list|3'],
'weave-library':['بافت‌های ذخیره‌شده پروژه','مرتب‌سازی|list|نام بافت','مجموعه|folder|بافت‌های پروژه'],
'weave-build':['ترسیم خانه‌های تار و پود','اندازه|grid|8 × 8','گام|draft-step|2'],
'weave-mapping':['تخصیص بافت به رنگ‌ها','پالت|palette|گلستان','روش|weave-mapping|رنگ به بافت','بافت پایه|basket|پاناما'],
'auto-map':['تخصیص خودکار بافت','مجموعه|weave-library|بافت‌های پروژه','روش|auto-map|بر اساس رنگ'],
'selvedge':['تنظیم دو کناره پارچه','عرض کناره|width|8','بافت|plain|تافته'],
'weft-insertion':['تعریف ترتیب پودها','ترتیب پود|weft|1, 2','تکرار|repeat|2'],
'float-control':['کنترل طول شناوری','حد تار|warp|5','حد پود|weft|5'],
'repeat-float':['کنترل مرز تکرار','حد فلوت|float-control|5','جهت|repeat|مستقیم'],
'tension-analysis':['بررسی تفاوت درگیری تارها','بازه|grid|یک راپورت','نمایش|report|نمودار'],
'repeat-seam':['بررسی پیوستگی لبه‌ها','محور|shift|افقی و عمودی','محدوده|rect-mask|یک راپورت'],
'quality-control':['کنترل نقشه پیش از خروجی','دامنه|grid|کل نقشه','گزارش|report|خلاصه'],
'machine-definition':['تنظیمات ماشین پروژه','شناسه|machine-definition|JQ-01','عرض|width|1200'],
'machine-output':['تنظیمات فایل ماشین','ماشین|machine-definition|JQ-01','ترتیب|warp|از راست'],
'fabric-simulation':['نمای نزدیک تار و پود','تراکم|density|24','بافت|weave-library|بافت پروژه'],
'image-table-export':['خروجی نقش و جدول','قالب تصویر|png|PNG','جدول رنگ|grid|همراه تصویر'],
'design-record':['مشخصات و رنگ‌های طرح','نام|text|گلستان','نسخه|file|1.0'],
'report':['گزارش مشخصات پروژه','بخش|list|همه بخش‌ها','قالب|pdf|PDF']
};
const LIB=['weave-mapping','weave-library','color-management','vector-editor','weave-build','fabric-simulation'];
const state0=()=>({view:'flow',node:'weave-mapping',tab:0,zoom:100,palette:['#294D67','#BE704E','#CDA363','#79927C','#F6EEDB'],ink:'#294D67',paper:'#F6EEDB',leaf:'#79927C',currentLayer:0,layerNames:['گل و ترنج','ساقه و برگ','زمینه'],layerOrder:[0,1,2],artW:640,artH:480,strokeColor:'#294D67',lineWidth:1.2,alpha:100,starPoints:5,dx:1,dy:0,satinN:8,satinStep:3,visible:[true,true,true],locked:[false,false,false],size:8,draft:makeDraft(8,0),preset:0,bank:[{name:'پاناما ۲×۲',n:4,arr:makeDraft(4,1)}],name:'گلستان',draftName:'سرژه راست',file:'PP1–01.tif',img:BMAP,imgSize:'۱۲۰۴ × ۱۲۰۳',favorites:[],params:{},tool:'select',query:'',history:[],redo:[]});
function makeDraft(n,t){return Array.from({length:n*n},(_,i)=>{const x=i%n,y=i/n|0;return [((x-y+n)%n)<Math.max(1,n/4),((x>>1)+(y>>1))%2===0,(x+y)%2===0,((x+2*y)%n)===0,((x-Math.abs(n/2-y)+n)%n)<2][t]||false})}
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const fa=v=>String(v).replace(/\d/g,c=>'۰۱۲۳۴۵۶۷۸۹'[c]);

function starPath(cx,cy,r,n){return Array.from({length:2*n},(_,i)=>{const a=i*Math.PI/n-Math.PI/2,q=i%2?r*.45:r;return (i?'L':'M')+(cx+Math.cos(a)*q)+' '+(cy+Math.sin(a)*q)}).join(' ')+'Z'}

function shapeMarkup(sh,w,h){
 const x=sh.x*w,y=sh.y*h,c=esc(sh.col),stroke=Number(sh.stroke)||1.2;
 let shape='';
 if(sh.type==='rect')shape='<rect x="'+(x-16)+'" y="'+(y-14)+'" width="32" height="28" fill="'+c+'"/>';
 else if(sh.type==='ellipse')shape='<ellipse cx="'+x+'" cy="'+y+'" rx="16" ry="14" fill="'+c+'"/>';
 else if(sh.type==='text')shape='<text x="'+x+'" y="'+y+'" text-anchor="middle" font-family="Vazir" font-size="21" fill="'+c+'">نقش</text>';
 else if(sh.type==='favorites')shape='<path d="'+starPath(x,y,18,sh.points||5)+'" fill="'+c+'"/>';
 else shape='<path d="M'+(x-18)+' '+(y+12)+(sh.type==='curve'||sh.type==='arc'?' q18-36 36 0':' l36-24')+'" stroke="'+c+'" fill="none" stroke-linecap="round" stroke-width="'+stroke+'"/>';
 return '<g opacity="'+((sh.alpha??100)/100)+'">'+shape+'</g>';
}
function vectorArt(s){
 const base='<rect width="'+s.artW+'" height="'+s.artH+'" fill="url(#cloth)"/>';
 const more=(s.extraShapes||[]).filter(sh=>s.visible[sh.layer??0]).sort((a,b)=>s.layerOrder.indexOf(b.layer??0)-s.layerOrder.indexOf(a.layer??0)).map(sh=>shapeMarkup(sh,s.artW,s.artH)).join('');
 return base+more;
}
