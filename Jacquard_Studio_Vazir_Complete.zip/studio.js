let S=state0();
const $=id=>document.getElementById(id),stage=$('stage'),dlg=$('dialog'),content=$('content');let timer;
function draw(){stage.innerHTML=render(S);document.title=VIEWS[S.view]+' · '+S.name+' | Jacquard Studio'}
function closeBox(){if(dlg.open)dlg.close()}
function go(v){if(!Object.hasOwn(VIEWS,v))return;closeBox();S.view=v;S.tab=0;S.listPage=0;S.query='';S.zoom=100;if(VIEWMOD[v])S.node=VIEWMOD[v];draw()}
const li=(key,label,icon='')=>'<button data-do="'+esc(key)+'">'+(icon?iconSvg(icon):'')+esc(label)+'</button>';
function options(items){return '<div class="options">'+items.join('')+'</div>'}
function dialog(title,body){$('caption').textContent=title;content.innerHTML=body;if(!dlg.open)dlg.showModal()}
function notify(msg){$('toast').textContent=msg;clearTimeout(timer);timer=setTimeout(()=>$('toast').textContent='',2300)}
function iconSvg(k){return '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.35" stroke-linecap="round" stroke-linejoin="round"><title>'+esc(GLYPHS[k].name)+'</title>'+GLYPHS[k].d+'</svg>'}
function download(blob,name){const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1200)}
const saveText=(t,name,mime)=>download(new Blob([t],{type:mime}),name);
function checkpoint(){S.history.push({size:S.size,draft:S.draft.slice(),draftName:S.draftName,preset:S.preset});S.history=S.history.slice(-50);S.redo=[]}
function select(k){S.node=k;S.tab=0;S.view='flow';closeBox();draw()}
function updateParam(i){const [key,icon,def]=defs[S.node][i+1].split('|');dialog(key,'<form id="saveparam"><label>'+GLYPHS[icon].name+'<input name="val" maxlength="36" required value="'+esc(S.params[S.node+':'+i]??def)+'"></label><p><button class="action">اعمال تنظیمات</button></p></form>');$('saveparam').onsubmit=e=>{e.preventDefault();S.params[S.node+':'+i]=e.target.val.value.trim().slice(0,36);closeBox();draw()}}
function rename(obj,field,label){dialog(label,'<form id="nameform"><label>'+esc(label)+'<input name="val" maxlength="28" required value="'+esc(obj[field])+'"></label><p><button class="action">ذخیره</button></p></form>');$('nameform').onsubmit=e=>{e.preventDefault();obj[field]=e.target.val.value.trim()||obj[field];closeBox();draw()}}
function resetMat(n,p){checkpoint();S.size=n;S.preset=p;S.draft=makeDraft(n,p);S.draftName=['سرژه راست','پاناما','تافته','ساتین','جناغی'][p]||'بافت جدید';draw()}
function openSearch(initial=''){dialog('جست‌وجوی ابزار و ماژول','<label>نام ابزار یا ماژول<input id="searchfield" type="search"></label><div class="options" id="hits"></div>');const input=$('searchfield');input.value=initial;const run=()=>{const q=input.value.trim();$('hits').innerHTML=Object.keys(GLYPHS).filter(k=>(GLYPHS[k].name+' '+k).includes(q)).map(k=>li((GLYPHS[k].group==='module'?'pick:':'glyph:')+k,GLYPHS[k].name,k)).join('')||'موردی پیدا نشد.'};input.oninput=run;run();input.focus()}
function artifact(){const d=render(S).match(/<pattern id="cloth"[\s\S]*?<\/pattern>/)[0];return '<svg xmlns="http://www.w3.org/2000/svg" width="'+S.artW+'" height="'+S.artH+'" viewBox="0 0 '+S.artW+' '+S.artH+'"><defs>'+d+'<style>'+FONT_CSS+'</style></defs>'+vectorArt(S)+'</svg>'}
function project(){const {history,redo,...data}=S;return {format:'jacquard-ui-v1',data}}
function op(k){if(k==='pencil'){notify('با کلیک روی خانه، وضعیت آن تغییر می‌کند.');return}if(k==='undo'||k==='redo'){const from=k==='undo'?S.history:S.redo,to=k==='undo'?S.redo:S.history;if(!from.length){notify('تغییری برای بازگرداندن نیست');return}to.push({size:S.size,draft:S.draft.slice(),draftName:S.draftName,preset:S.preset});Object.assign(S,from.pop());draw();return}checkpoint();const a=S.draft,n=S.size;S.draft=a.map((b,i)=>k==='invert'?!b:k==='flip'?a[(i/n|0)*n+n-1-i%n]:a[((Math.floor(i/n)-S.dy%n+n)%n)*n+(i%n-S.dx%n+n)%n]);S.preset=-1;draw()}
function numbers(title,fields,done){dialog(title,'<form id="numform">'+fields.map(([key,label,v,min,max,step])=>'<label>'+label+'<input name="'+key+'" type="number" dir="ltr" required min="'+min+'" max="'+max+'" step="'+(step||1)+'" value="'+v+'"></label>').join('')+'<p><button class="action">اعمال</button></p></form>');$('numform').onsubmit=e=>{e.preventDefault();const a=Object.fromEntries(fields.map(([k])=>[k,+e.target.elements[k].value]));closeBox();done(a);draw()}}
function dispatch(id){const [cmd,arg,b]=id.split(':');switch(cmd){
case 'art-size':numbers('اندازه صفحه',[['artW','عرض (px)',S.artW,32,4096],['artH','ارتفاع (px)',S.artH,32,4096]],v=>Object.assign(S,v));return;
case 'style':numbers('ویژگی شیء جدید',[['alpha','شفافیت ٪',S.alpha,0,100],['lineWidth','ضخامت دورخط',S.lineWidth,.1,16,.1],['starPoints','تعداد پره‌ها',S.starPoints,3,16]],v=>Object.assign(S,v));return;
case 'satin-settings':numbers('ساخت ساتین',[['satinN','اندازه شبکه',S.satinN,3,24],['satinStep','گام',S.satinStep,1,23]],v=>{let a=v.satinN,b=v.satinStep;while(b){[a,b]=[b,a%b]}if(a!==1||v.satinStep>=v.satinN){notify('گام باید از اندازه کوچک‌تر و نسبت به آن اول باشد.');return}checkpoint();Object.assign(S,v);S.size=v.satinN;S.draft=Array.from({length:S.size**2},(_,i)=>(Math.floor(i/S.size)*S.satinStep)%S.size===i%S.size);S.draftName='ساتین';S.preset=-1});return;
case 'shift-settings':numbers('جابجایی خانه‌ها',[['dx','ΔX',S.dx,-24,24],['dy','ΔY',S.dy,-24,24]],v=>{Object.assign(S,v);op('shift')});return;
case 'mix-weave':if(!S.bank.length){notify('ابتدا یک بافت به بانک اضافه کنید');return}dialog('ترکیب شبکه با بافت بانک',options(S.bank.map((v,i)=>li('mix:'+i,v.name,'weave-library'))));return;
case 'mix':{const b=S.bank[+arg];if(!b)return;checkpoint();S.draft=S.draft.map((v,i)=>v||b.arr[(Math.floor(i/S.size)%b.n)*b.n+(i%S.size)%b.n]);S.draftName='بافت ترکیبی';S.preset=-1;closeBox();draw();return}
case 'remove-weave':dialog('انتخاب بافت برای حذف',options(S.bank.map((x,i)=>li('del-weave:'+i,x.name,'delete'))));return;
case 'del-weave':S.bank.splice(+arg,1);closeBox();draw();return;
case 'add-layer':{let i=S.layerNames.length;S.layerNames.push('لایه '+fa(i+1));S.layerOrder.unshift(i);S.currentLayer=i;S.visible[i]=true;S.locked[i]=false;draw();return}
case 'del-layer':{const i=S.currentLayer;if(i<3||S.locked[i]){notify('لایه‌های پایه و لایه‌های قفل‌شده حفظ می‌شوند.');return}S.visible[i]=false;S.layerOrder=S.layerOrder.filter(x=>x!==i);S.currentLayer=S.layerOrder[0];draw();return}
case 'raise-layer':case 'lower-layer':{const i=S.layerOrder.indexOf(S.currentLayer),j=i+(cmd==='raise-layer'?-1:1);if(j>=0&&j<S.layerOrder.length){[S.layerOrder[i],S.layerOrder[j]]=[S.layerOrder[j],S.layerOrder[i]];draw()}return}
case 'rename-layer':rename(S.layerNames,S.currentLayer,'نام لایه');return;
case 'remove-shape':{const idx=(S.extraShapes||[]).findLastIndex(sh=>sh.layer===S.currentLayer);if(idx>=0&&!S.locked[S.currentLayer])S.extraShapes.splice(idx,1);draw();return}
case 'view':go(arg);return;case 'close':closeBox();return;
case 'navigation':dialog('محیط‌های پروژه',options(Object.entries(VIEWS).map(([k,v])=>li('view:'+k,v,VIEWMOD[k]||'grid')))+'<div class="pagechoice"></div>'+options([li('save','ذخیره پروژه','save'),li('import-project','باز کردن پروژه','open'),li('download-screen','ذخیره نمای جاری','svg'),'<a class="dl" href="preview/Jacquard_Studio_Vazir.pdf" target="_blank">پیش‌نمایش PDF</a>']));return;
case 'pick':if(GLYPHS[arg]?.group==='module')select(arg);return;
case 'add':case 'search':openSearch();return;
case 'favorites':dialog('ابزارهای نشان‌شده',S.favorites.length?options(S.favorites.map(k=>li('pick:'+k,GLYPHS[k].name,k))):'با ستارهٔ کنار هر ماژول، آن را به این فهرست اضافه کنید.');return;
case 'fav':S.favorites=S.favorites.includes(arg)?S.favorites.filter(k=>k!==arg):[...S.favorites,arg];draw();return;
case 'open-part':if(VIEWFOR[S.node])go(VIEWFOR[S.node]);else dialog(GLYPHS[S.node].name,'<p>'+defs[S.node][0]+'</p>'+options(defs[S.node].slice(1).map((v,i)=>li('param:'+i,v.split('|')[0],v.split('|')[1]))));return;
case 'param':updateParam(+arg);return;case 'tab':S.tab=+arg;draw();return;
case 'details':S.tab=['flow','catalog','icons'].includes(S.view)?2:1;draw();return;
case 'copy-settings':saveText(JSON.stringify({module:S.node,parameters:defs[S.node].slice(1).map((l,i)=>[l.split('|')[0],S.params[S.node+':'+i]??l.split('|')[2]])},null,2),S.node+'.json','application/json');return;
case 'reset-settings':for(const k in S.params)if(k.startsWith(S.node+':'))delete S.params[k];draw();notify('تنظیمات پیش‌فرض ماژول اعمال شد');return;
case 'zoom':dialog('بزرگ‌نمایی بوم',options([75,90,100,110,125].map(v=>li('scale:'+v,fa(v)+'٪','zoom-in'))));return;
case 'scale':S.zoom=+arg;closeBox();draw();return;
case 'save':saveText(JSON.stringify(project()),'Golestan-project.json','application/json');return;
case 'import-project':closeBox();$('projectFile').click();return;
case 'change-image':$('imageFile').click();return;
case 'next':S.listPage=(S.listPage||0)+1;draw();return;case 'prev':S.listPage=Math.max(0,(S.listPage||0)-1);draw();return;
case 'glyph':dialog(GLYPHS[arg].name,'<div class="iconbig">'+iconSvg(arg)+'</div>'+options([li('icon:'+arg,'ذخیره آیکون SVG','save-as')]));return;
case 'icon':saveText(iconSvg(arg),arg+'.svg','image/svg+xml');return;
case 'tool':S.tool=arg;draw();return;
case 'layer':S.currentLayer=+arg;draw();return;case 'choose-layer':S.tab=1;draw();return;
case 'lock':S.locked[+arg]=!S.locked[+arg];draw();return;case 'eye':S.visible[+arg]=!S.visible[+arg];draw();return;
case 'color':if(S.locked[S.currentLayer]){notify('لایه قفل است');return}if(S.currentLayer<3)S[['ink','leaf','paper'][S.currentLayer]]=S.palette[+arg];else S.ink=S.palette[+arg];draw();return;
case 'export-art':saveText(artifact(),'Golestan-pattern.svg','image/svg+xml');return;
case 'export-png':{const im=new Image(),url=URL.createObjectURL(new Blob([artifact()],{type:'image/svg+xml'}));im.onload=()=>{const cv=document.createElement('canvas');cv.width=S.artW;cv.height=S.artH;cv.getContext('2d').drawImage(im,0,0);URL.revokeObjectURL(url);cv.toBlob(x=>{if(x)download(x,'Golestan-pattern.png')})};im.onerror=()=>{URL.revokeObjectURL(url);notify('خروجی تصویر ایجاد نشد')};im.src=url;return}
case 'cell':checkpoint();{const i=+b*S.size+Number(arg);S.draft[i]=!S.draft[i];S.preset=-1;draw()}return;
case 'op':op(arg);return;case 'size':resetMat(+arg,S.preset);return;case 'sample':resetMat(S.size,+arg);return;
case 'name-weave':rename(S,'draftName','نام بافت');return;case 'rename':rename(S,'name','نام طرح');return;
case 'save-weave':S.bank.push({name:S.draftName,n:S.size,arr:S.draft.slice()});go('bank');notify('بافت به بانک پروژه افزوده شد');return;
case 'bank':{const item=S.bank[+arg];if(item){checkpoint();S.size=item.n;S.draft=item.arr.slice();S.draftName=item.name;S.preset=-1;draw()}return}
case 'new-weave':resetMat(8,-1);go('weave');return;
case 'download-screen':saveText(render(S).replace('<defs>','<defs><style>'+FONT_CSS+'</style>'),S.view+'.svg','image/svg+xml');return;
}}
document.addEventListener('click',e=>{const bv=e.target.closest('[data-do]');if(bv){dispatch(bv.dataset.do);return}const dr=e.target.closest('[data-draw]');if(dr){if(S.locked[S.currentLayer]){notify('لایه قفل است');return}const svg=dr.ownerSVGElement,pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;const local=pt.matrixTransform(dr.getScreenCTM().inverse()),br=dr.getBBox();(S.extraShapes||=[]).push({type:S.tool,layer:S.currentLayer,stroke:S.lineWidth,alpha:S.alpha,points:S.starPoints,x:(local.x-br.x)/br.width,y:(local.y-br.y)/br.height,col:S.ink});draw();return}const g=e.target.closest('[data-act]');if(g)dispatch(g.dataset.act)});
document.addEventListener('keydown',e=>{const g=e.target.closest('[data-act]');if(g&&[' ','Enter'].includes(e.key)){e.preventDefault();dispatch(g.dataset.act)}});
$('imageFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{S.file=f.name.slice(0,36);S.img=r.result;S.imgSize=fa(im.width)+' × '+fa(im.height);draw()};im.src=r.result};r.readAsDataURL(f)};
$('projectFile').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;const v=JSON.parse(await f.text()),d=v.data;if(v.format!=='jacquard-ui-v1'||!Object.hasOwn(VIEWS,d.view)||!Object.hasOwn(GLYPHS,d.node)||!(Number.isInteger(d.size)&&d.size>=3&&d.size<=24)||d.draft?.length!==d.size*d.size||!Array.isArray(d.bank)||!Array.isArray(d.palette)||!Array.isArray(d.favorites)||!(d.img||'').startsWith('data:image/'))throw Error();const candidate=Object.assign(state0(),d,{history:[],redo:[]});render(candidate);S=candidate;draw();notify('پروژه باز شد')}catch{notify('این فایل پروژه قابل باز کردن نیست')}};
document.fonts.ready.then(draw);draw();
